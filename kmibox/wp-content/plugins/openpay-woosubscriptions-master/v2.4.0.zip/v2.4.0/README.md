# openpay-woosubscriptions
Plugin para módulo de suscripciones de WooCommerce, actualmente compatible con la versión 2.4.0
